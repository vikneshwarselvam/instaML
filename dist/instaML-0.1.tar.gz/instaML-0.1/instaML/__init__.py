
__author__ = """Vikneshwar Selvam"""
__email__ = 'selvamvikneshwar@gmail.com'

from instaML.facial_recognition.facial_rec import load_image_file, face_locations, batch_face_locations, face_landmarks, face_encodings, compare_faces, face_distance
